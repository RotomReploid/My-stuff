function hello(){
    let x = prompt();
}