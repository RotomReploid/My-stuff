function first(){ 
console.log("butt")
document.querySelector("#butt").innerText = "butt";
}