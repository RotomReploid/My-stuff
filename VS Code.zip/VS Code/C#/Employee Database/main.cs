using System;

namespace MyApp
{
    class Program
    {
        static void Main(string[] fhqwhgads)
        {
            Console.ReadKey();
        }
    }
}