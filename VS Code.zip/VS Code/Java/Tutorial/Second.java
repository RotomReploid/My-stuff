public class Second {
  int x = 2;
  
  public static void main(String[] args){
  }
}