public class Main {
  int x = 12;
  
  public static void main(String[] args){
    Main Obj = new Main();
    Second Obj2 = new Second();
    System.out.println(Obj.x);
    System.out.println(Obj2.x);
  }
}